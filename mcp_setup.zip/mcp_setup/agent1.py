from fastapi import FastAPI
from pydantic import BaseModel
from fastmcp import FastMCP
import ollama
import requests
import json

app = FastAPI(title="Calculator Agent MCP Server")

MCP_URL = "http://localhost:8000/mcp"  # Child MCP server

def get_mcp_tools():
    resp = requests.get(f"{MCP_URL}/tools")
    if resp.ok:
        tools = resp.json()
        print("Discovered tools:", [t["name"] for t in tools])
        return tools
    return []

def call_tool(tool_name: str, args: dict):
    resp = requests.post(f"{MCP_URL}/tools/{tool_name}", json=args)
    return resp.json() if resp.ok else {"error": "Tool failed"}

tools_schemas = get_mcp_tools()

# Manual MCP tools endpoint for HTTP access
@app.get("/mcp/tools")
async def get_mcp_tools_http():
    return [{"name": "ask_calculator_agent", 
             "description": "Full agent for loans/SIPs with reasoning. Delegates to MCP tools.", 
             "inputSchema": {"type": "object", "properties": {"query": {"type": "string"}}, "required": ["query"]}}]

class QueryInput(BaseModel):
    query: str

@app.post("/mcp/tools/ask_calculator_agent", response_model=dict)
async def ask_calculator_agent(input: QueryInput):
    """Full agent for loans/SIPs with reasoning. Delegates to MCP tools."""
    ollama_tools = []
    for tool in tools_schemas:
        ollama_tools.append({
            "type": "function",
            "function": {
                "name": tool["name"],
                "description": tool.get("description", ""),
                "parameters": tool["inputSchema"]
            }
        })
    
    response = ollama.chat(
    model="qwen2.5:7b-instruct-q4_0",  # Larger model helps
    messages=[
        {
            "role": "system",
            "content": """You are a precise financial calculator agent. 
            
For sip_calculator: CALCULATE monthly_sip needed for target (e.g., query 'SIP to 1Cr 15yrs 12%' → solve monthly_sip≈₹37k), annual_return_rate=query %, years=query years. 
For loan_calculator: principal=loan amount, annual_rate=query %, years=query years.
EXTRACT/derive EXACT numbers from query. Use reverse calc if target given. No assumptions—precise params only."""
        },
        {"role": "user", "content": input.query}
    ],
    tools=ollama_tools
    )   

    msg = response["message"]
    
    if "tool_calls" in msg:
        for tc in msg["tool_calls"]:
            tool_name = tc["function"]["name"]
            args = tc["function"]["arguments"]
            print(f"{tool_name}: {args}")
            result = call_tool(tool_name, args)
            print(f"Result: {result}")
        
        # Final reasoning with tool results
        final = ollama.chat(
            model="qwen2.5:7b-instruct-q4_0",
            messages=[
                {"role": "user", "content": input.query},
                msg,
                {"role": "tool", "content": json.dumps(result)}  # Simplified; loop if multiple
            ]
        )
        return {"content": final["message"]["content"]}
    
    return {"content": msg["content"]}

# MCP stdio server (primary)
mcp = FastMCP.from_fastapi(app, name="Calculator Agent")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)
