import ollama
import requests
import json

TOP_MCP_URL = "http://localhost:8001/mcp"  # Your MCPllm server (the "child agent")

def get_mcp_tools():
    resp = requests.get(f"{TOP_MCP_URL}/tools")
    print(resp.text)
    tools = resp.json()
    print("Discovered child agent tools:", [t["name"] for t in tools])
    return tools

def call_child_agent_tool(tool_name, args):
    resp = requests.post(f"{TOP_MCP_URL}/tools/{tool_name}", json=args)
    return resp.json() if resp.ok else {"error": "Child agent failed"}

# Mirror your MCPllm.py pattern
tool_schemas = get_mcp_tools()
print(tool_schemas)
ollama_tools = []
for tool in tool_schemas:
    ollama_tools.append({
        "type": "function",
        "function": {
            "name": tool["name"],
            "description": tool.get("description", ""),
            "parameters": tool["inputSchema"]
        }
    })

def top_financial_agent(query):
    """Top agent: reasons over complex queries, delegates to child MCPllm agent."""
    response = ollama.chat(
        model="qwen2.5:7b-instruct-q4_0",
        messages=[{"role": "user", "content": query}],
        tools=ollama_tools
    )
    msg = response["message"]
    
    if "tool_calls" in msg:
        for tc in msg["tool_calls"]:
            tool_name = tc["function"]["name"]
            args = tc["function"]["arguments"]
            print(f"Top → Child agent: {tool_name}({args})")
            result = call_child_agent_tool(tool_name, args)
            print(f"Child → Top: {result}")
        
        # Final reasoning with child results
        final = ollama.chat(
            model="qwen2.5:7b-instruct-q4_0",
            messages=[
                {"role": "user", "content": query + f"\nChild agent results: {json.dumps(result)}"}
            ]
        )
        return final["message"]["content"]
    return msg["content"]

# Demo
if __name__ == "__main__":
    print(top_financial_agent("Plan a SIP of 50k/month for 15 years at 12% return. Also, EMI for 30L loan at 7.5% for 15 years."))
